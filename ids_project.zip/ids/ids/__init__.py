"""ids — Python Hybrid Intrusion Detection System."""
